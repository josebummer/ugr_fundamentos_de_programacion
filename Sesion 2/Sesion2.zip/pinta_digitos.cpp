#include <iostream>

using namespace std;

int main () {

	char a,b,c;
	
	cout << "Introduce un numero de 3 cifras: ";
	cin >> a;
	cin >> b;
	cin >> c;
	
	cout << a << "\t" << b << "\t" << c << "\n\n";
	
	system("pause");
	

}
