/*
Recuperad la soluci�n del ejercicio 30 de la Relaci�n de Problemas II (Empresa). Reescribid
el programa principal usando una clase Ventas para gestionar los c�mputos
de las ventas realizadas. �nicamente se pide que se indiquen las cabeceras de los
m�todos p�blicos de la clase y las llamadas a �stos en el programa principal. No hay
que implementar ninguno de los m�todos.
Debe suponer que la clase gestionar� las ventas de exactamente tres sucursales. Los
c�digos de dichas sucursales son enteros cualesquiera (no necesariamente 1, 2, 3,
como ocurr�a en el ejercicio 30 de la Relaci�n de Problemas II)
*/

#include <iostream>

using namespace std;

class Ventas{
	private:
		static const int TAMANIO=3;
		int id_sucursal[TAMANIO],productos_sucursal[TAMANIO],i;
	
	public:
		Ventas(){
			for(i=0;i<3;i++)
				id_sucursal[i]=i+1;
			for(i=0;i<3;i++)
				productos_sucursal[i]=0;
		}
		Ventas(int id_sucursal1, int productos_sucursal1, int id_sucursal2, int productos_sucursal2, int id_sucursal3, int productos_sucursal3){
			id_sucursal[0]=id_sucursal1;
			productos_sucursal[0]=productos_sucursal1;
			id_sucursal[1]=id_sucursal2;
			productos_sucursal[1]=productos_sucursal2;
			id_sucursal[2]=id_sucursal3;
			productos_sucursal[2]=productos_sucursal3;
		}
		
		int GetSucursal(int posicion){
			if(posicion<3 && posicion>=0)
				return id_sucursal[posicion];
		}
		void SetSucursal(int posicion, int id){
			if(posicion<3 && posicion>=0)
				id_sucursal[posicion]=id;
		}
		
		int GetProductosSucursal(int posicion){
			if(posicion<3 && posicion>=0)
				return productos_sucursal[posicion];
		}
		void SetProductosSucursal(int posicion, int cantidad){
			if(posicion<3 && posicion>=0)
				productos_sucursal[posicion]=cantidad;
		}
		
		void SumarProductos(int sucursal, int cantidad){
			int i;
			for(i=0;i<3;i++)
				if(GetSucursal(i)==sucursal)
					productos_sucursal[i]+=cantidad;
		}
		
		int MaximoSucursal(){
			int maximo=GetProductosSucursal(0);
			if(GetProductosSucursal(1)>maximo)
				maximo=GetProductosSucursal(1);
			if(GetProductosSucursal(2)>maximo)
				maximo=GetProductosSucursal(2);
			return maximo;
		}
		int IdMaximoSucursal(){
			int id_maximo,i,maximo;
			maximo=MaximoSucursal();
			for(i=0;i<3;i++)
				if(maximo==GetProductosSucursal(i))
					id_maximo=GetSucursal(i);
		return id_maximo;
		}
};

int main(){

	const int FIN=-1;
	char producto;
	Ventas venta_empresa;
	int sucursal, cantidad,i;
	
	for(i=0;i<3;i++){
		do{
			cout << "Introduce la sucursal: ";
			cin >> sucursal;
		}while(sucursal<1);
		venta_empresa.SetSucursal(i,sucursal);
		do{
			cout << "Introduce la cantidad inicial de la sucursal " << venta_empresa.GetSucursal(i) << ": ";
			cin >> cantidad;
		}while(cantidad<0);
		venta_empresa.SetProductosSucursal(i,cantidad);
	}
	cout << "PASEMOS hA INTRODUCIR CANTIDADES A LAS SUCURSALES CREADAS.\n\n";
	
	do{
			cout << "Introduce la sucursal (-1 para salir): ";
			cin >> sucursal;
		}while(sucursal!=venta_empresa.GetSucursal(0) && sucursal!=venta_empresa.GetSucursal(1) && sucursal!=venta_empresa.GetSucursal(2) && sucursal!=FIN);
	
	while(sucursal!=FIN){
		do{
			cout << "Introduce el producto (a,b,c): ";
			cin >> producto;
		}while(producto!='a' && producto!='b' && producto!='c');
		do{
			cout << "Introduce la cantidad: ";
			cin >> cantidad;
		}while(cantidad<0);
		
		venta_empresa.SumarProductos(sucursal,cantidad);
		
		do{
			cout << "\nIntroduce la sucursal (-1 para salir): ";
			cin >> sucursal;
		}while(sucursal!=venta_empresa.GetSucursal(0) && sucursal!=venta_empresa.GetSucursal(1) && sucursal!=venta_empresa.GetSucursal(2) && sucursal!=FIN);
		
	}
	
	cout << "\nLa sucursal con id " << venta_empresa.IdMaximoSucursal() << " es la sucursal que mas productos a vendido con " << venta_empresa.MaximoSucursal() << " productos.\n\n";
	
system("pause");
}
