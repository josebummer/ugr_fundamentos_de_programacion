/*
Recupere la soluci�n del ejercicio 6 de esta relaci�n de problemas (c�mputo del salario
en funci�n de las horas trabajadas) Defina una clase Nomina para gestionar el
c�mputo del salario final. Suponga que el porcentaje de incremento en la cuant�a de
las horas extras (50 %) y el n�mero de horas que no se tarifan como extra (40) son
valores que podr�an cambiar, aunque no de forma continua. El n�mero de horas trabajadas
y la cuant�a a la que se paga cada hora extraordinaria, s� son cantidades que
var�an de un trabajador a otro.
*/

#include <iostream>

using namespace std;

class Nomina{
	private:
		const int HORASMAX=40;
		const int PORCENTAJE=50;
		int horas_trabajadas,precio_hora;
	public:
		
		Nomina(){
			horas_trabajadas=1;
			precio_hora=1;
		}
		Nomina(int valorhoras,int valorprecio){
			horas_trabajadas=valorhoras;
			precio_hora=valorprecio;
		}
		
		void SetHoras(int valorhoras){
			horas_trabajadas=valorhoras;
		}
		int GetHoras(){
			return horas_trabajadas;
		}
		
		void SetPrecio(int valorprecio){
			precio_hora=valorprecio;
		}

};

double SalarioTrabajador(int horas,int precio){

	const int MAX=40;
	double salario;
	int horas_extras=0;
	
	if(horas>MAX){
		horas_extras=horas-MAX;
		horas-=horas_extras;
		
		salario=horas_extras*precio*1.5;
	}
	
	salario+=horas*precio;
	
return salario;
}

int main(){

	int precio_hora,horas;
	double salario;
	
	do{
	cout << "Introduce el precio al que es paga la hora: ";
	cin >> precio_hora;
	}while(precio_hora<0);
	do{
	cout << "Introduce el numero de horas trabajadas: ";
	cin >> horas;
	}while(horas<0);
	
	salario=SalarioTrabajador(horas,precio_hora);
	
	cout << "\nEl trabajador ha ganado: " << salario << " euros.\n\n";

system("pause");
}
