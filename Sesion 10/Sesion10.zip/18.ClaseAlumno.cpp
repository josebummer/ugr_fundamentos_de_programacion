/*
Definir la clase AlumnoFP, que almacene el nombre, el primer apellido, el DNI del
alumno y cada una de las partes consideradas en la evaluaci�n de la asignatura: teor�a,
parcial_pract1, parcial_pract2, participaci�n_clase. La escala utilizada para evaluar
cada parte es de 0 a 10.
 Construir los constructores necesarios para poder asignar valores a los miembros
de la clase.
 Construir un m�todo que calcule la nota final del alumno. Para ello se debe de
tener en cuenta los porcentajes de las distintas partes consideradas: 70% teor�a,
5% parcial 1, 15% parcial 2 y 10% participaci�n.
 Construir un m�todo que calcule la nota final del alumno.
 Construir un programa que lea los datos del alumno y en caso de haber obtenido
una nota inferior a 5 en alguna de las partes que indique la nota obtenida en dicha
parte.
*/

#include <iostream>
#include <string>

using namespace std;

class AlumnoFP{
	private:
		string nombre,apellido,DNI;
		double teoria,parcial_pract1,parcial_pract2,participacion_clase;
	public:
		AlumnoFP(string valornombre, string valorapellido, string valorDNI, double valorteoria, double valorparcial_pract1,double valorparcial_pract2,
		double valorparticipacion_clase){
			nombre=valornombre;
			apellido=valorapellido;
			DNI=valorDNI;
			teoria=valorteoria;
			parcial_pract1=valorparcial_pract1;
			parcial_pract2=valorparcial_pract2;
			participacion_clase=valorparticipacion_clase;
		}
		AlumnoFP(){
		
			AlumnoFP("SN","SA","00000000A",1,1,1,1);
		
		}
		void SetNombre(string valornombre){
			nombre=valornombre;
		}
		string GetNombre(){
			return nombre;
		}
		
		void SetApellido(string valorapellido){
			apellido=valorapellido;
		}
		string GetApellido(){
			return apellido;
		}
		
		void SetDNI(string valorDNI){
			DNI=valorDNI;
		}
		string GetDNI(){
			return DNI;
		}
		
		void SetTeoria(double valorteoria){
			teoria=valorteoria;
		}
		double GetTeoria(){
			return teoria;
		}
		
		void SetParcial_pract1(double valorparcial_pract1){
			parcial_pract1=valorparcial_pract1;
		}
		double GetParcial_pract1(){
			return parcial_pract1;
		}
		
		void SetParcial_pract2(double valorparcial_pract2){
			parcial_pract2=valorparcial_pract2;
		}
		double GetParcial_pract2(){
			return parcial_pract2;
		}
		
		void SetParticipacion(double valorparticipacion_clase){
			participacion_clase=valorparticipacion_clase;
		}
		double GetParticipacion(){
			return participacion_clase;
		}
		
		void SetValores(string valornombre, string valorapellido, string valorDNI, double valorteoria, double valorparcial_pract1,double valorparcial_pract2,
		double valorparticipacion_clase){
		
			nombre=valornombre;
			apellido=valorapellido;
			DNI=valorDNI;
			teoria=valorteoria;
			parcial_pract1=valorparcial_pract1;
			parcial_pract2=valorparcial_pract2;
			participacion_clase=valorparticipacion_clase;
			
		}
		
		double CalcTeoria(){
			return teoria*0.7; 
		}
		
		double CalcParcial1(){
			return parcial_pract1*0.05;
		}
		
		double CalcParcial2(){
			return parcial_pract2*0.15;
		}
		
		double CalcParticipacion(){
			return participacion_clase*0.1;
		}
		
		double NotaFinal(){
			return CalcTeoria()+CalcParcial1()+CalcParcial2()+CalcParticipacion();
		}

};

int main(){

	static const int TAMANIO=4;
	double notas[TAMANIO];
	int i;
	AlumnoFP alumno;
	string nombre="",apellido="",DNI="";

	cout << "Introduce tu nombre: ";
	cin >> nombre;
	cout << "Introduce tu primer apellido: ";
	cin >> apellido;
	do{
	cout << "Introduce tu DNI: ";
	cin >> DNI;
	}while(DNI.size()!=9);
	cout << "\n\nAhora introduce las notas en orden: TEORIA, PARCIAL1, PARCIAL2, PARTICIPACION (de 0 a 10).\n";
	for(i=0;i<TAMANIO;i++){
	
		do{
			cout << "Introduce el " << i+1 << " valor: ";
			cin >> notas[i];
		}while(notas[i]<0 || notas[i]>10);
	
	}
	
	alumno.SetValores(nombre,apellido,DNI,notas[0],notas[1],notas[2],notas[3]);

	cout << "\n\nAlumno: " << alumno.GetNombre() << " " << alumno.GetApellido() << "\nDNI: " << alumno.GetDNI() << "\n";
	cout << "La nota final del alumno es: " << alumno.NotaFinal() << ".";
	
	if(alumno.GetTeoria()<5)
		cout << "\nSuspenso en TEORIA con un " << alumno.GetTeoria() << " que para la nota final puntua con " << alumno.CalcTeoria();
	if(alumno.GetParcial_pract1()<5)
		cout << "\nSuspenso en PRACTICO 1 con un " << alumno.GetParcial_pract1() << " que para la nota final puntua con " << alumno.CalcParcial1();
	if(alumno.GetParcial_pract2()<5)
		cout << "\nSuspenso PRACTICO 2 con un " << alumno.GetParcial_pract2() << " que para la nota final puntua con " << alumno.CalcParcial2();
	if(alumno.GetParticipacion()<5)
		cout << "\nTiene en participacion un " << alumno.GetParticipacion() << " que para la nota final puntua con " << alumno.CalcParticipacion();
	cout << "\n\n";

system("pause");
}
