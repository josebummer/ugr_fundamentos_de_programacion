////////////////////////////////////////////////////////////////////////////
//
// Fundamentos de Programaci�n
// ETS Inform�tica y Telecomunicaciones
// Universidad de Granada
// Departamento de Ciencias de la Computaci�n e Inteligencia Artificial
// Autor: Juan Carlos Cubero
//
////////////////////////////////////////////////////////////////////////////

/*
Razonar sobre la falsedad o no de las siguientes afirmaciones:
a) 'c' es una expresi�n de caracteres.
   V. 
   'c' es un literal de tipo char, el caso m�s sencillo de expresi�n de tipo char
   
b) 4 < 3 es una expresi�n num�rica.
   F
   Es una expresi�n l�gica. Devuelve un bool
   Eso s�, los argumentos del operador relacional < deben ser expresiones num�ricas.
   
c) (4+3) < 5 es una expresi�n num�rica.
   F
   Lo mismo que antes
   
d) cout << a; da como salida la escritura en pantalla de una a.
   Si a es una variable de tipo de dato char y se le ha asignado 'a',
   s� ser�a correcto. En otro caso, es falso.

e) �Qu� realiza cin >> cte, siendo cte una constante entera?
   Error en tiempo de compilaci�n
*/



